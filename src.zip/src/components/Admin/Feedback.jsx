import React from 'react';

const Feedback = () => {
  return (
    <div className='vh-100'>
      <h1>Feedback Section</h1>
    </div>
  );
}

export default Feedback;
